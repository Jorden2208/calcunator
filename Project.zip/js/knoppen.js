
function knopTafels(){
  document.getElementById("canvas").style.display = "none";
  document.getElementById("tafels").style.display = "block";
  document.getElementById("Machten").style.display = "none";
  document.getElementById("breuken").style.display = "none";
  document.getElementById("priem").style.display = "none";
  document.getElementById("pig").style.display = "none";
  document.getElementById("uitlegText").innerHTML = "Voer bij GETAL het getal in dat vermenigvuldigd moet worden. <br><br> Voer bij <br>TOT GETAL het getal in tot waar de sommen moeten lopen. ";
}
function knopMachten(){
  document.getElementById("canvas").style.display = "none";
  document.getElementById("Machten").style.display = "block";
  document.getElementById("tafels").style.display = "none";
  document.getElementById("breuken").style.display = "none";
  document.getElementById("priem").style.display = "none";
  document.getElementById("pig").style.display = "none";
  document.getElementById("uitlegText").innerHTML = "Voer bij GETAL het getal in waarvan u de macht wilt weten. <br><br> Voer bij <br>TOT GETAL het getal in tot waar de sommen moeten lopen.";
}
function knopWelkom(){
  document.getElementById("tafels").style.display = "none";
  document.getElementById("canvas").style.display = "block";
  document.getElementById("Machten").style.display = "none";
  document.getElementById("breuken").style.display = "none";
  document.getElementById("priem").style.display = "none";
  document.getElementById("pig").style.display = "none";
  document.getElementById("uitlegText").innerHTML = "welkom terug bij de homepage..";
}
function knopBreuken(){
  document.getElementById("tafels").style.display = "none";
  document.getElementById("canvas").style.display = "none";
  document.getElementById("Machten").style.display = "none"; 
  document.getElementById("breuken").style.display = "block";
  document.getElementById("priem").style.display = "none";
  document.getElementById("pig").style.display = "none";
  document.getElementById("uitlegText").innerHTML = "Voer bij GETAL het getal in waarvan u de breuken wilt weten. <br><br> Voer bij <br>TOT GETAL het getal in tot waar de sommen moeten lopen.";
}
function knopPriem(){
  document.getElementById("tafels").style.display = "none";
  document.getElementById("canvas").style.display = "none";
  document.getElementById("Machten").style.display = "none";
  document.getElementById("breuken").style.display = "none";
  document.getElementById("priem").style.display = "block";
  document.getElementById("pig").style.display = "none";
  document.getElementById("uitlegText").innerHTML = "Voer bij GETAL het getal in waarvan u de priemgetallen wilt weten. <br><br> Voer bij <br>TOT GETAL het getal in tot waar de sommen moeten lopen.";
}
function knopPig(){
  document.getElementById("tafels").style.display = "none";
  document.getElementById("canvas").style.display = "none";
  document.getElementById("Machten").style.display = "none";
  document.getElementById("breuken").style.display = "none";
  document.getElementById("priem").style.display = "none";
  document.getElementById("pig").style.display = "block";
  document.getElementById("uitlegText").innerHTML = "Deze pagina is helaas nog niet helemaal af gekomen.. <br><br> COME <br> BACK <br> LATER..";
	
}
