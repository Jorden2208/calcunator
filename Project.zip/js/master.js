function krijgSom(){
var tafels = document.getElementById('tafels');
if(document.getElementById('tafels').style.display == "block"){
    rekenTafels();
}
if(document.getElementById('Machten').style.display == "block"){
    rekenMachten();
}
if(document.getElementById('breuken').style.display == "block"){
    rekenBreuken();
}
if(document.getElementById('priem').style.display == "block"){
    rekenPriem();
}
if(document.getElementById('pig').style.display == "block"){
    pig();
}
}
